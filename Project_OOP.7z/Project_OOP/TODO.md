# todo

    - 6 assignments
    - proj innov
    - quiz 6pm
    - study math
    - study oop
    - study arabic
    - study innov
    - study statistics
    - study circuits

#

<!-- revision -->

    - statements
    - loops
    - functions
    - classes
    - arrays
    - user inputs
    - inheritance
    - importing

    - relationships
    - refrence/pointers
    - memory management
    - polymorphism
    - capsulation
    - Function overloading
    - constructors



    - list
    - structures
    - uml chart

# Proj Bank

## login

    - add/remove customers/employees
    - customer/admin

## people

### employees

    - information

### customers

    -> vip
    -> normal
    - trade currency between them
    - convert currency.
    - loans

## logic

    - calculator
    - log

## Gui

    -console {c}

# Other

    - Brawl
    - one pizza
    - Gen
