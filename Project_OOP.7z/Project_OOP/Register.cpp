#include <iostream>
#include <string>

void add(Customer customer[], int &num_users)
{
    std::string name;
    int id;
    int number;
    std::string password;
    int balance;

    std::cout << "enter name: ";
    std::cin >> name;
    std::cout << "enter id: ";
    std::cin >> id;
    std::cout << "enter number: ";
    std::cin >> number;
    std::cout << "enter password: ";
    std::cin >> password;
    std::cout << "enter balance: ";
    std::cin >> balance;
    std::cout << std::endl;
    num_users++;

    customer[num_users] = Customer(name, id, balance, number, password);
    std::cout << std::endl;
    std::cout << "user added." << std::endl;
    std::cout << std::endl;
    Menu();
}

void remove()
{
    std::string name;
    std::cout << "enter name: ";
    std::cin >> name;
    std::cout << std::endl;
    std::cout << "enter password: ";
    std::string password;
    std::cin >> password;
    std::cout << std::endl;

    for (int i = 0; i < SIZE; i++)
    {
        if (customer[i].name == name && customer[i].password == password)
        {
            customer[i].name = "";
            customer[i].id = 0;
            customer[i].number = 0;
            customer[i].password = "";
            customer[i].balance = 0;
            std::cout << "user removed." << std::endl;
            std::cout << std::endl;
            Menu();
        }
        else if (i == SIZE - 1)
        {
            std::cout << "user not found..." << std::endl;
            std::cout << std::endl;
            Menu();
        }
    }
}

void Register()
{
    // uses classes  add, remove, replace,
}